/* application header */
#include <co_datatype.h>

#define UNAME_LEN 256
extern char uname[];
extern char notification[];
extern char uptime[];
extern char date[];
