/*
* main.c - contains main function of the example program
*
* Copyright (c) 2012-2013 emtas GmbH
*-------------------------------------------------------------------
* $Id: main.c 9922 2015-07-14 11:23:57Z oe $
*
*
*-------------------------------------------------------------------
*
*
*/

/********************************************************************/
/**
* \file
* \brief main routine
*
* Simple CANopen slave running under Linux operating system.
* Depending on how the Make is called, can be used with can4linux or SocketCAN.
* No IO hardware is required. Some Object Dictionary entries 
* are provided to read some OS specific strings, See *.eds.
* CiA 401 Object 6200 is available. Writing to it is simulated
* by using printf() to display IO settings on stdout.
*/

/* header of standard C - libraries
---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* used to open /sys/class/gpio files */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>



#if defined(__linux__)
# include <unistd.h>		/* usleep(), getpid() */
#include <sys/time.h>		/* rusage() */
#include <sys/resource.h>	/* rusage() */
#else
# define usleep(s)
#endif

/* header of project specific types
---------------------------------------------------------------------------*/
#include <gen_define.h>

#include <co_canopen.h>

#include "terminal.h"   /* for coloring LED output */
#include "application.h"

/* constant definitions
---------------------------------------------------------------------------	*/
#define CAN_BITRATE 250					/* default CAN bit rate to use		*/
#define CAN_DEFAULT_DEVICE "/dev/can0"	/* default CAN device to use		*/ 

#define CO_401_PROFILE_OFFSET	0 

/* local defined data types
---------------------------------------------------------------------------*/

/* list of external used functions, if not in headers
--------------------------------------------------------------------------*/

/* list of global defined functions
---------------------------------------------------------------------------*/

/* list of local defined functions
---------------------------------------------------------------------------*/
static RET_T nmtInd(BOOL_T	execute, CO_NMT_STATE_T newState);
static void hbState(UNSIGNED8	nodeId, CO_ERRCTRL_T state,
		CO_NMT_STATE_T	nmtState);
static RET_T sdoServerReadInd(BOOL_T execute, UNSIGNED8	sdoNr, UNSIGNED16 index,
		UNSIGNED8	subIndex);
static RET_T sdoServerCheckWriteInd(BOOL_T execute, UNSIGNED8 node,
		UNSIGNED16 index, UNSIGNED8	subIndex, const UNSIGNED8 *pData);
static RET_T sdoServerWriteInd(BOOL_T execute, UNSIGNED8 sdoNr,
		UNSIGNED16 index, UNSIGNED8	subIndex);
static void pdoInd(UNSIGNED16);
static void pdoRecEvent(UNSIGNED16);
static void canInd(CO_CAN_STATE_T);
static void commInd(CO_COMM_STATE_EVENT_T);
static void ledGreenInd(BOOL_T);
static void ledRedInd(BOOL_T);
static void showLEDs(void);

void byte_out_printf(UNSIGNED8 port);
void get_version(void);
void calculate_rusage(void);
void usage(void);

/* process io handling */
int init_gpio_out(void);
void byte_out(UNSIGNED8 port);


/* external variables
---------------------------------------------------------------------------*/

/* global variables
---------------------------------------------------------------------------*/
UNSIGNED16	test;
int use_gpio	= 1;		/* use /proc/sys/class/gpio */
char uname[UNAME_LEN]; 
char uptime[UNAME_LEN];
char date[UNAME_LEN];

char can_device_name[100];
char notification[100];

/* local defined variables
---------------------------------------------------------------------------*/
static UNSIGNED8	nodeId = 32;


/* local defined functions */
/***************************************************************************/
/**
* \brief - set an 8 bit digital output - printf()
*
* This simple version uses only printf() to print the information
* to the stdout of the process.
*
* \return void
*
*/
void byte_out_printf(
		UNSIGNED8 port			/**< selected 8bit port */
	)
{
UNSIGNED8 value;
UNSIGNED8 invert;
UNSIGNED8 retval;

	(void)coOdGetObj_u8(0x6200u + CO_401_PROFILE_OFFSET, port, &value); 
	/* get the polarity invert value for this port */
	retval = coOdGetObj_u8(0x6202u + CO_401_PROFILE_OFFSET, port, &invert); 
	if(retval == RET_OK) {
		// CO_DEBUG2("401: Polarity for dig out %d available 0x%02x\n", port, invert);
		value ^= invert;
	}
	printf("digout port:%2d, value:0x%02x, %3d\n",
			port, value, value);
}


/***************************************************************************/
/**
* \brief - read out the os version string
*
* The functions reads /proc/version and copies the string
* to the application variable \e uname .
*
* \return void
*
*/
void get_version(void)
{
FILE *fp;
	fp = fopen("/proc/version", "r");
	if (fp != NULL) {
		fgets(uname, UNAME_LEN, fp);
		fclose(fp);
	} else {
		strncpy(uname, "can't open /proc/version", UNAME_LEN);
	}
}

/***************************************************************************/
/**
* \brief - help for command line usage
*
* \return void
*/
void usage(void)
{
	printf("CANopen CiA 401 Linux example, compiled " __DATE__ " $Revision: 9922 $ \n");
	printf("use: slave* [-b bitrate] [-D device] [-n nodeId]\n");
	printf(" -g		don't use process io via gpio\n");
}

void calculate_rusage(void)
{
struct rusage usage;
int user   		= 0;
static int old_user   	= 0;

	getrusage(RUSAGE_SELF, &usage);
	user = usage.ru_utime.tv_usec - old_user; 
	old_user = usage.ru_utime.tv_usec;

	/* if the value of user doesn't change, than the value is the same
	   it looks like the values are update once every second,
	   therefore we can use the new, update vale to
	   set it in relation to one second */

	printf("%8ld : %8ld : %4d\n", usage.ru_utime.tv_sec, usage.ru_utime.tv_usec, user);

	

}
/***************************************************************************/
/**
* \brief main entry
*
* \param
*	nothing
* \results
*	nothing
*/
int main(
	int argc,
	char *argv[]
  )
{
UNSIGNED8	emcyData[5] = { 1, 2, 3, 4, 5 };
RET_T ret;
int c;				/* getopt() */
extern char *optarg;
extern int optind;
int baud = CAN_BITRATE;			/* default CAN bit rate to use */

	printf("CANopen CiA 401 Linux example, compiled " __DATE__ "\n");

	/* set default CAN device name */
	strncpy(can_device_name, CAN_DEFAULT_DEVICE, 100);

	while ((c = getopt(argc, argv, "b:D:hgn:")) != EOF) {
		switch (c) {
			case 'b':
				baud = atoi(optarg);
				break;
			case 'D':
				if (
					/* path ist starting with '.' or '/', use it as it is */
					optarg[0] == '.'
					|| 
					optarg[0] == '/'
					) {
					snprintf(can_device_name, 50, "%s", optarg);

					} else {
					snprintf(can_device_name, 50, "/dev/%s", optarg);
				}
				break;
			case 'n':
				nodeId = atoi(optarg);
				break;
			case 'g':	/* don't use gpio */
				use_gpio	= 0;
				break;
			case 'h':
			default: usage(); exit(0);
		}
	}


	if (use_gpio) {
		/* initialize process hardware
		 * in this simple case these are some pins used via /sys/class/gpio */
		if (init_gpio_out() != 0) {
			fprintf(stderr, "Can not set or reserve gpio pins\n"); 	
			fprintf(stderr, "Try calling as root, or disable io with parameter \"-g\"\n"); 	
			exit(1);
		}
		printf("successful initialized GPIO pins for digital out\n");
	}

	/* now open the driver */
	if (codrvCanInit(baud) != RET_OK)  {
		fprintf(stderr, "error init CAN driver %s\n", can_device_name);
		exit(1);
	}
	printf("successful initialized CAN driver %s with bit rate %d Kbit/s\n",
			can_device_name, baud);

    ret = coCanOpenStackInit(NULL);
    if (ret != RET_OK)  {
		fprintf(stderr, "error init library, ret = %d\n", ret);
		exit(1);
	}
	printf("successful initialized CANopen stack\n");

	if (codrvTimerSetup(CO_TIMER_INTERVAL) != RET_OK)  {
		fprintf(stderr, "error setup CANopen timer\n");
		exit(2);
	}
	printf("successful set up CANopen timer\n");

	/* register event functions */
	if (coEventRegister_NMT(nmtInd) != RET_OK)  {
		fprintf(stderr, "error register NMT indication\n");
		exit(3);
	}
	printf("successful registered NMT indication\n");

	if (coEventRegister_ERRCTRL(hbState) != RET_OK)  {
		exit(4);
	}
	printf("successful registered CANopen Error control\n");

	if (coEventRegister_SDO_SERVER_READ(sdoServerReadInd) != RET_OK)  {
		exit(5);
	}
	printf("successful registered SDO read indication\n");

	if (coEventRegister_SDO_SERVER_CHECK_WRITE(sdoServerCheckWriteInd) != RET_OK)  {
		exit(6);
	}
	printf("successful registered SDO write indication\n");

	if (coEventRegister_SDO_SERVER_WRITE(sdoServerWriteInd) != RET_OK)  {
		exit(7);
	}
	if (coEventRegister_PDO(pdoInd) != RET_OK)  {
		exit(8);
	}
	printf("successful registered PDO write indication\n");

	if (coEventRegister_PDO_REC_EVENT(pdoRecEvent) != RET_OK)  {
		exit(9);
	}
	if (coEventRegister_LED_GREEN(ledGreenInd) != RET_OK)  {
		exit(10);
	}
	if (coEventRegister_LED_RED(ledRedInd) != RET_OK)  {
		exit(11);
	}
	if (coEventRegister_CAN_STATE(canInd) != RET_OK)  {
		exit(12);
	}

	if (coEventRegister_COMM_EVENT(commInd) != RET_OK)  {
		exit(13);
	}


	/* --------------------------------------------------------- */
	/* set some object dictionary values before starting CANopen */
	get_version();
	(void)coOdPutObj_u32(0x2002, 0, (UNSIGNED32)getpid()); 		

	/* --------------------------------------------------------- */

	if (codrvCanEnable() != RET_OK)  {
		exit(14);
	}
	printf("successfully enabled CAN driver\n");

	/* write emcy */
	printf("Send out a dummy EMCY\n");
	if (coEmcyWriteReq(0x1234, &emcyData[0]) != RET_OK)  {
		exit(15);
	}

	printf("== Going into application loop ==\n");
	/* use notify in KDE, if not available
	 * does not matter, "command not found is displayd on stderr */
	system("notify-send \"CANopen started\"");

#define MAXC 5000
	{
	int i = 0;
		while (1)  {
			// usleep(2000);
			codrvWaitForEvent(2);
			coCommTask();
			if (i++ == MAXC) {
				i = 0;
			} 
			coOdPutObj_u16(0x3000, 1, i);
			coOdPutObj_u16(0x3000, 2, MAXC - i);
		}
	}
}


/*********************************************************************/
UNSIGNED8 getNodeId()
{
	return(nodeId);
}


/*********************************************************************/
static RET_T nmtInd(
		BOOL_T	execute,
		CO_NMT_STATE_T	newState
	)
{
    if (!execute) return RET_OK;

	printf("nmtInd: New NMT state %d\n", newState);
	showLEDs();

	return(RET_OK);
}


/*********************************************************************/
static void pdoInd(
		UNSIGNED16	pdoNr
	)
{
	printf("pdoInd: pdo %d received\n", pdoNr);
	if (pdoNr == 1) {
		/* the one and only supported PDO */
		byte_out_printf(1);
		byte_out(1); 
		/* other ports are not used physically */
		byte_out_printf(2);
		byte_out_printf(3);
	}
	showLEDs();
	
}


/*********************************************************************/
static void pdoRecEvent(
		UNSIGNED16	pdoNr
	)
{
	printf("pdoRecEvent: pdo %d time out\n", pdoNr);
	showLEDs();
}


/*********************************************************************/
static void hbState(
		UNSIGNED8	nodeId,
		CO_ERRCTRL_T state,
		CO_NMT_STATE_T	nmtState
	)
{
	printf("hbInd: HB Event %d node %d nmtState: %d\n", state, nodeId, nmtState);
	showLEDs();

    return;
}

void command(char *cmd, char *buf);
/* execute command and put stdout into buf */
void command(char *cmd, char *buf)
{
FILE *ptr;

	   // fprintf(stderr, "do: %s\n", cmd);
	   if ((ptr = popen(cmd, "r")) != NULL) {
		   usleep(2000);
		   fprintf(stderr, "pipe open %p OK, %d\n", ptr, UNAME_LEN);
		   fprintf(stderr, ">%s<\n", fgets(buf, UNAME_LEN, ptr));
		   while (fgets(buf, UNAME_LEN, ptr) != NULL) {

			   fprintf(stderr, "line\n");
					   fprintf(stdout, "> %s", buf);
		   }
		   pclose(ptr);
	   }
}

/*********************************************************************/
static RET_T sdoServerReadInd(
		BOOL_T		execute,
		UNSIGNED8	sdoNr,
		UNSIGNED16	index,
		UNSIGNED8	subIndex
	)
{
#if 0
	printf("sdo server read ind: exec: %d, sdoNr %d, index %x:%d\n",
		execute, sdoNr, index, subIndex);
#endif

	if (index == 0x2003 && execute == 1) {
		printf("client is reading the uptime\n");
		command("/usr/bin/uptime", uptime);
	}
	if (index == 0x2004 && execute == 1) {
		printf("client is reading the date\n");
		command("/bin/date", date);
	}
	return(RET_OK);
}


/*********************************************************************/
static RET_T sdoServerCheckWriteInd(
		BOOL_T		execute,
		UNSIGNED8	sdoNr,
		UNSIGNED16	index,
		UNSIGNED8	subIndex,
		const UNSIGNED8	*pData
	)
{
#if 0
	printf("sdo server check write ind: exec: %d, sdoNr %d, index %x:%d\n",
		execute, sdoNr, index, subIndex);
#endif
   // return(RET_INVALID_PARAMETER);
	return(RET_OK);
}


/*********************************************************************/
static RET_T sdoServerWriteInd(
		BOOL_T		execute,
		UNSIGNED8	sdoNr,
		UNSIGNED16	index,
		UNSIGNED8	subIndex
	)
{
#if 0
	printf("sdo server write ind: exec: %d, sdoNr %d, index %x:%d\n",
		execute, sdoNr, index, subIndex);
#endif
    if (!execute) return RET_OK;

	if ((index == 0x6200) && (subIndex > 0)) {

		/* Call the HW API */
		// byte_out_printf(subIndex, value);
		byte_out_printf(subIndex);
		byte_out(subIndex);
		showLEDs();
	}

	if (index == 0x2100) {
		char command[256];
		snprintf(command, 256, "notify-send \"%s\"", notification);
		system(command);
	}

	return(RET_OK);
}


/*********************************************************************/
static void canInd(
	CO_CAN_STATE_T	canState
	)
{
	switch (canState)  {
		case CO_CAN_STATE_BUS_OFF:
			printf("CAN: Bus Off\n");
			break;
		case CO_CAN_STATE_BUS_ON:
			printf("CAN: Bus On\n");
			break;
		case CO_CAN_STATE_PASSIVE:
			printf("CAN: Passiv\n");
			break;
		default:
			break;
	}
}


/*********************************************************************/
static void commInd(
		CO_COMM_STATE_EVENT_T	commEvent
	)
{
	switch (commEvent)  {
		case CO_COMM_STATE_EVENT_BUS_OFF:
			printf("COMM-Event Bus Off\n");
			break;
		case CO_COMM_STATE_EVENT_BUS_OFF_RECOVERY:
			printf("COMM-Event Bus Off\n");
			break;
		case CO_COMM_STATE_EVENT_BUS_ON:
			printf("COMM-Event Bus On\n");
			break;
		case CO_COMM_STATE_EVENT_PASSIVE:
			printf("COMM-Event Bus Passive\n");
			break;
		case CO_COMM_STATE_EVENT_ACTIVE:
			printf("COMM-Event Bus Active\n");
			break;
		case CO_COMM_STATE_EVENT_CAN_OVERRUN:
			printf("COMM-Event CAN Overrun\n");
			break;
		case CO_COMM_STATE_EVENT_REC_QUEUE_FULL:
			printf("COMM-Event Rec Queue Full\n");
			break;
		case CO_COMM_STATE_EVENT_REC_QUEUE_OVERFLOW:
			printf("COMM-Event Rec Queue Overflow\n");
			break;
		case CO_COMM_STATE_EVENT_TR_QUEUE_FULL:
			printf("COMM-Event Tr Queue Full\n");
			break;
		case CO_COMM_STATE_EVENT_TR_QUEUE_OVERFLOW:
			printf("COMM-Event Tr Queue Empty\n");
			break;
		case CO_COMM_STATE_EVENT_TR_QUEUE_EMPTY:
			printf("COMM-Event Tr Queue Empty\n");
			break;
		default:
			break;
	}

}

/* CANopen indicator LED handling
 *
 * The CANopen stack fully controls available LEDs
 * The Application has to register two indication functions
 * one for each color, using coEventRegister_LED_GREEN()
 * and coEventRegister_LED_RED() and fill the indication functions
 * with code to control the LEDs
 *
 * In the Linux example we use stdout to display the LED status.
 *
 */
/* define colors */
#define RED     ATTBOLD FGRED
#define GREEN   ATTBOLD FGGREEN

/* define LED index */
#define LGREEN  0
#define LRED    1

static int leds[2] = { 0 , 0 };

/*********************************************************************/
static void showLEDs(void)
{
	printf("> " GREEN "%c  " RED "%c"  ATTRESET "\r",
		leds[LGREEN] ? 'O' : ' ',
		leds[LRED]   ? 'O' : ' ');
	fflush(stdout);
}

/*********************************************************************/
static void ledGreenInd(
		BOOL_T	on
	)
{
	//printf("GREEN: %d\n", on);
	leds[LGREEN] = on;
	showLEDs();
}


/*********************************************************************/
static void ledRedInd(
		BOOL_T	on
	)
{
	// printf("RED: %d\n", on);
	leds[LRED] = on;
	showLEDs();
}



/* 
Standard Linux kernel have inside a special interface allow to access to GPIO pins.
The interface to allow working with GPIO is at the following filesystem path:
	/sys/class/gpio/

Read: https://www.kernel.org/doc/Documentation/gpio/sysfs.txt
*/

int init_gpio_out()
{
/* declare possible output pins */
int out[] = { 251, 252};

#define BUFSIZE 100
char buf[BUFSIZE];
int i, fd;

	for (i = 0; i < (sizeof(out)/sizeof(int)); i++) {
		// printf("configure gpio%d\n", out[i]);

		/* First:
		 * export the Pin to the file system */
		fd = open("/sys/class/gpio/export", O_WRONLY);
		if (fd < 0) {
			return -1;
		}
		snprintf(buf, BUFSIZE, "%d", out[i]); 
		write(fd, buf, strlen(buf));
		close(fd);
		/* Second:
		 * set output direction */
		sprintf(buf, "/sys/class/gpio/gpio%d/direction", out[i]);
		fd = open(buf, O_WRONLY);
		write(fd, "out", 3);
		close(fd);
	}
	return 0;
}


/***************************************************************************/
/**
* \brief - set an 8 bit digital output at /sys/class/gpio
*
* This version uses /sys/class/gpio to control defined gpio pins
* as digital outputs.
*
* File handling is not optimized. Everytime a bit is written,
* /sys/class/gpio/pin/value
* is opened and closed.after the value was written.
* 
* \return void
*
*/
void byte_out(
		UNSIGNED8 port			/**< selected 8bit port */
	)
{
UNSIGNED8 value;
UNSIGNED8 invert;
UNSIGNED8 retval;
int i;

	/* current implementation is
	 * GPIO[0]: IO_0_34 - > BoraEVB JP21.16 -  sysfs gpio 251
	 * GPIO[1]: IO_25_34 - > BoraEVB JP21.15  - sysfs gpio 252
	 */
		/* [port - 1][gpiopin]  n ports, 8 bit each
		 * gpiopin 0xff == 255 is invalid, not available */
UNSIGNED8 gpiopin[3][8] = { {251, 252, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff}, 
					   {0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
					   {0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff}
					 };

	if (use_gpio == 0) return;

	(void)coOdGetObj_u8(0x6200u + CO_401_PROFILE_OFFSET, port, &value); 
	/* get the polarity invert value for this port */
	retval = coOdGetObj_u8(0x6202u + CO_401_PROFILE_OFFSET, port, &invert); 
	if(retval == RET_OK) {
		// CO_DEBUG2("401: Polarity for dig out %d available 0x%02x\n", port, invert);
		value ^= invert;
	}

	for (i = 0; i < 8; i++) {
		/* for all 8 io lines of this 8bit digital out port */
		int v;
		int fd;
		char buf[100];
		char *one  = "1";
		char *zero = "0";

		v = value & (1 << i);

		sprintf(buf, "/sys/class/gpio/gpio%d/value", gpiopin[port - 1][i]);
		fd = open(buf, O_WRONLY);
	// printf("write to port %d, bit %d using gpio%d value %d\n", port, i, gpiopin[port - 1][i], v ? 1  : 0);
		if (v == 0) {
			write(fd, zero, 1);
		} else {
			write(fd, one, 1);
		}
		close(fd);
	}
}

/* vim: set ts=4 sw=4 spell spelllang=en : */

